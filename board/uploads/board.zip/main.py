# -*- coding:utf-8 -*-
from flask import Flask, jsonify, g, request,session
from flask import render_template,redirect, url_for
import sqlite3
import hashlib

DATABASE='./db/test.db'
app = Flask(__name__)
app.secret_key ='abcd'
def get_db():
    db = getattr(g, '_database', None)
    if db  is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None: db.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()


def add_register(user_id,user_pw,user_em):
    pw = hashlib.sha224(user_pw).hexdigest()
    sql = 'INSERT INTO register (user_id, user_pw, user_em) VALUES ("%s", "%s", "%s")' %(user_id, pw, user_em)
    db = get_db()
    db.execute(sql)
    res = db.commit()
    return res

def get_user(user_id, user_pw):
    pw = hashlib.sha224(user_pw).hexdigest()
    sql= 'SELECT * FROM register where user_id ="%s" and user_pw ="%s"' %(user_id,pw)
    db = get_db()
    rv = db.execute(sql)
    res = rv.fetchall()
    return res

def get_email(user):
    sql = 'SELECT user_em FROM register where user_id="%s"' %(user)
    db = get_db()
    rv = db.execute(sql)
    res = rv.fetchall()
    return res

@app.route('/')
def users():
    return jsonify(hello='word')


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        user_id = request.form.get('user_id')
        user_pw = request.form.get('user_pw')
        data = get_user(user_id, user_pw)
        print data
        if len(data) != 0:
            session['is_logged'] = True
            session['user_id'] = user_id
            session['user_pw'] = user_pw
            return '<a href="/secret">login success</a>'
        else:
            return 'Login Failed'

@app.route('/register', methods=['GET', 'POST'])
def user_resgister():
    if request.method == 'GET':
        return render_template('user_register.html')
    else:
        user_id = request.form.get('user_id')
        user_pw = request.form.get('user_pw')
        user_em = request.form.get('user_em')
        session['user_em'] = user_em
        add_register(user_id,user_pw,user_em)
        return render_template('login.html')


@app.route('/secret')
def secret():
    if session['is_logged'] == True:
        email = get_email(session['user_id'])[0]['user_em']
        return render_template('secret.html', email = email)
    else:
        return '로그인해주세요<br><a href="/login">로그인</a>'


@app.route('/logout')
def logout():
    if session['is_logged'] == True:
        session.pop('is_logged')
        session['is_logged'] = False
        return 'logout<br><a href="/login">로그인</a>'

@app.route('/update', methods=['GET','POST'])
def update():
    if request.method =='GET':
        return render_template('update.html')
    else:
        update_id = request.form.get('update_id')
        update_pw = request.form.get('update_pw')
        update_em = request.form.get('update_em')
        update_data(update_id, update_pw,update_em)
        return render_template('update.html')

def update_data(user,userpw,em):
    pw = hashlib.sha224(userpw).hexdigest()
    sql = 'UPDATE register SET user_id = "%s" where user_id = "%s"' %(user, session['user_id'])
    sql1 = 'UPDATE register SET user_pw = "%s" where user_pw = "%s"' %(userpw, session['user_pw'])
    sql2 = 'UPDATE register SET user_em = "%s" where user_em = "%s"' %(em, session['user_em'])

    db = get_db()
    db.execute(sql)
    db.execute(sql1)
    db.execute(sql2)
    res = db.commit()

@app.route('/board')
def board():
    data = read_board()
    return render_template('board.html', data = data)

def read_board():
    sql = 'SELECT * FROM board '
    db = get_db()
    rv = db.execute(sql)
    res = rv.fetchall()
    return res

@app.route('/write',methods=['GET','POST'])
def write_board():
    if request.method == 'GET':
        return render_template('write.html')
    else:
        title = request.form.get('title')
        data = request.form.get('data')
        user_id = session['user_id']
        write(title, data, user_id)
        return redirect(url_for('board'))

def write(title, data, user):
    sql = "INSERT INTO board (title, data, user_id) VALUES ('%s','%s','%s')" %(title, data, user)
    db = get_db()
    rv = db.execute(sql)
    res = db.commit()

@app.route('/data',methods=['GET','POST'])
def board_data():
    index = request.args.get('index')
    data = read_data(index)[0]
    session['write']=data['user_id']
    result = request.form.get('reply_data')
    reply_list = None
    if result != None:
        write_reply(result,index,session['write'])
    if read_reply(index) != []:
        reply_list = read_reply(index)
        print reply_list
    return render_template('data.html', data=data,index_=index,reply_list =reply_list)

def read_reply(index):
    sql ="SELECT * FROM contexttb where myindex = '%s'" %(index)
    db = get_db()
    rv = db.execute(sql)
    res = rv.fetchall()
    return res

def write_reply(reply,index,user):
    sql="INSERT INTO contexttb (context,user_id,myindex) VALUES ('%s','%s','%s')" %(reply,user,index) 
    db = get_db()
    rv = db.execute(sql)
    res = db.commit()

def read_data(index):
    sql = "SELECT * FROM board where idx ='%s'" %(index)
    db = get_db()
    rv = db.execute(sql)
    res = rv.fetchall()
    return res

@app.route('/data_update')
def dataupdate():
    if session['user_id'] == session['write']:
        return render_template('data_update.html')
    else:
        return "수정 권한이 없습니다."
@app.route('/data_update1',methods=['GET','POST'])
def dataupdate1():
    if request.method=='GET':
        return render_template('data_update1.html')
    else:
        tit = request.form.get('titlt')
        da = request.form.get('data')
        data_modi(tit,da)
        data = data_read()
        return render_template('data_update1.html', data=data)

#def data_modi():
#    sql = "UPDATE"

#def data_read():


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=8081)
